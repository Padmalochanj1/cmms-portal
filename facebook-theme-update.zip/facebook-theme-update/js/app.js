
(()=>{
const C=window.CMMS_CONFIG,L=window.CMMS,$=s=>document.querySelector(s),T=sessionStorage.cmmsToken,U=sessionStorage.cmmsUser,HOD=sessionStorage.cmmsSection==="hod",SEC=HOD?(new URLSearchParams(location.search).get("sec")||""):"",R=HOD?"mgmt":sessionStorage.cmmsRole;
if(!T){location.replace("../index.html");return}
if(HOD&&(!SEC||SEC==="ops")){location.replace(SEC==="ops"?"ops.html?sec=ops":"hod.html");return}
if(sessionStorage.cmmsSection==="ops"){location.replace("ops.html");return}
const ACTIVE_SEC=HOD?SEC:sessionStorage.cmmsSection;
if(ACTIVE_SEC==="ei"||ACTIVE_SEC==="mech")document.documentElement.dataset.sectionTheme="facebook";
const SECN={ei:"E&I",mech:"Mechanical",ops:"Operation"},UN=HOD?String(sessionStorage.cmmsUnit||"").replace(/ HOD$/,"")+" "+(SECN[SEC]||SEC):(sessionStorage.cmmsUnit||"Coal Washery E&I");if(HOD&&window.HODBAR)HODBAR.mount(SEC);$("#unitH").textContent=UN+" maintenance management";document.title=UN+" Maintenance Management Portal";
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const opDay=()=>{const d=new Date(Date.now()-216e5);return Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/864e5};
let M,TD=opDay(),route=(location.hash||"#dashboard").slice(1),cl={},ms={},RG={days:7,cl:{},ms:{},done:false},rf="Pending",pastOrder=null,cur="",fromClosing=false,items=[],sub="closure",hist=null,hd=L.iso(TD),dirty=false;
let EX=[],NAMES={},NM=sessionStorage.cmmsName||U;const bn=u=>NAMES[u]||u;const V={},A={};const ALL=[["dashboard","Dashboard"],["closing","Order closing"],["report","Closure report"],["checklist","Checklist closing"],["tomorrow","Tomorrow’s orders"],["notifications","Notifications"],["neworder","Create order"],["reliability","MTTR / MTBF"]],ROUTES=(R==="mgmt"?ALL.filter(r=>["dashboard","report","tomorrow","notifications","neworder","reliability"].includes(r[0])&&!(HOD&&r[0]==="neworder")):ALL).concat(R==="admin"||R==="mgmt"?[["admin","Admin"]]:[]);
const toast=(m,bad)=>{const t=$("#toast");t.textContent=m;t.className=bad?"bad show":"show";clearTimeout(toast.t);toast.t=setTimeout(()=>t.className="",6000)};
async function call(a,b){if(!/^https:\/\//i.test(C.url||""))throw new Error("The server address is not set. Open js/config.js and paste your Worker address.");let j;try{const r=await fetch(C.url,{method:"POST",body:JSON.stringify({token:T,action:a,...(HOD?{sec:SEC}:{}),...b}),signal:AbortSignal.timeout(45000)});j=await r.json()}
 catch(e){throw new Error("The server did not respond. Check the URL in config.js and that the Apps Script deployment access is set to Anyone.")}
 if(j.error){if(/Session expired/.test(j.error)){sessionStorage.clear();location.replace("../index.html")}if(/change your password first/i.test(j.error))location.replace("../index.html");throw new Error(j.error)}return j}
async function load(){const d=await call("load",{date:L.iso(TD)});if(!d.master)throw new Error("No data received from the server.");M=d.master;EX=d.extras||[];NAMES=d.names||{};NM=NAMES[U]||U;sessionStorage.cmmsName=NAMES[U]||"";cl=Object.fromEntries(d.closures.map(c=>[c.no,c]));ms=Object.fromEntries(d.measurements.map(m=>[m.no,1]));
 $("#sub").textContent=`${NM}${HOD?" (HOD view, view only)":""}  |  Operational date ${L.iso(TD).split("-").reverse().join("/")}`;draw()}
const KL={resched:"Rescheduled",additional:"Additional",attention:"Attention action"},OTYPES={PM:"Preventive Maintenance",CM:"Corrective Maintenance",IM:"Inspection / Lubrication / Compliance",OM:"Overhauling / Refurbishment",IO:"Improvement Order"};
const toOrder=x=>({no:x.no,e:M.equipment.find(e=>e.id===x.eq)||{id:x.eq,name:x.name,type:x.type||"",loc:x.loc||"",crit:x.crit||""},ix:-1,fi:-1,freq:x.freq,due:L.dn(x.due),extra:x});
const ordersOn=t=>L.orders(M,t).concat(EX.filter(x=>x.due===L.iso(t)).map(toOrder));
const st=o=>{const c=cl[o.no]||RG.cl[o.no];return c?c.action.toUpperCase():(ms[o.no]||RG.ms[o.no])?"READY TO CLOSE":o.extra&&!o.extra.chk?"OPEN":L.items(M,o).length?"OPEN":"NO CHECKLIST"};
const cc=(o,s)=>s==="READY TO CLOSE"||(!!o.extra&&!o.extra.chk&&s==="OPEN");
const ckBtn=o=>o.extra&&!o.extra.chk?"":`<button class="link" data-a="chk">Checklist</button> `;
const xinfo=o=>o.extra?`<small><b>${KL[o.extra.kind]||"Extra"}${o.extra.otype?" ("+o.extra.otype+")":""}</b>${o.extra.title?": "+esc(o.extra.title):""}${o.extra.src?" (from "+esc(o.extra.src)+")":""}</small>`:"";

const ol=(no,due)=>`<a href="#" class="ono mono" data-ono="${esc(no)}" data-due="${esc(due)}">${esc(no)}</a>`;
const procOf=o=>o&&o.e&&o.freq?String(((M.procedures||{})[o.e.type+"|"+o.freq])||"").trim():"";
const kv=(a,b)=>`<div><span>${a}</span>${b==null||b===""?"—":esc(b)}</div>`;
function prevOf(o){const x=o.extra;
 if(x){if(x.kind==="resched"&&x.src){const m=/-R\d+$/.test(x.src)?null:/-(\d{2})(\d{2})(\d{2})$/.exec(x.src),pe=m?null:EX.find(e=>e.no===x.src);const d=m?"20"+m[1]+"-"+m[2]+"-"+m[3]:pe?pe.due:"";return d?{no:x.src,due:d}:null}return null}
 for(let t=o.due-1;t>=o.due-400;t--){const p=L.orders(M,t).find(q=>q.ix===o.ix&&q.fi===o.fi);if(p)return{no:p.no,due:L.iso(t)}}return null}
const ckTbl=(o,rec)=>rec?tbl(["Seq.","Check item","Reading","Acceptance criteria","Mandatory","OK / NOT OK","Result","Notes"],rec.items.map((i,k)=>`<tr><td>${k+1}</td><td>${esc(i.item)}</td><td>${esc(i.reading)} ${esc(i.unit||"")}</td><td>${esc(i.criteria||"")}</td><td>${esc(i.mand||"")}</td><td>${esc(i.ok||"")}</td><td>${i.result?chip(i.result):""}</td><td>${esc(i.notes||"")}</td></tr>`)):
 (o.extra&&!o.extra.chk)||!L.items(M,o).length?`<p class="empty">No checklist for this order.</p>`:tbl(["Seq.","Check item","Unit","Reading required","Acceptance criteria","Mandatory"],L.items(M,o).map(r=>`<tr><td>${r.seq}</td><td>${esc(r.item)}</td><td>${esc(r.unit||"")}</td><td>${esc(r.readReq||"")}</td><td>${esc(r.criteria||"")}</td><td>${esc(r.mand||"")}</td></tr>`));
const closeInfo=(c,m)=>c?[["Action",c.action],["Closed on",c.on?dmy(c.on):""],["Closed by",bn(c.by)],["Start time",c.start],["End time",c.end],["Duration",dur(c.start,c.end)],["Remarks",c.rem],["Deferred to",c.newDate?dmy(c.newDate):""]].filter(r=>r[0]!=="Deferred to"||r[1]).map(([a,b])=>kv(a,b)).join(""):kv("Closure","Not closed")+(m?kv("Checklist","Saved, ready to close"):"");
function orderOf(no,due,d){const t=L.dn(due);let o=ordersOn(t).find(x=>x.no===no);if(o)return o;if(d.extra)return toOrder(d.extra);const r=d.closure||d.measurement||{},id=r.eq||(/-(\d{4})-\d{6}$/.exec(no)||[])[1];return{no,e:M.equipment.find(e=>e.id===id||e.id.slice(-4)===id)||{id:id||"",name:r.name||"",type:r.type||"",loc:r.loc||"",crit:r.crit||""},ix:-1,fi:-1,freq:r.freq||"",due:t,extra:null}}
function odShow(no,due){document.getElementById("odlg")?.remove();const bk=document.createElement("div");bk.id="odlg";bk.className="mback";
 bk.innerHTML=`<div class="mbox" role="dialog" aria-modal="true"><div class="mhead"><h2 class="mono">${esc(no)}</h2><button class="ghost" data-odx>Close</button></div><div id="odb"><p class="empty">Loading...</p></div></div>`;document.body.appendChild(bk);
 const shut=()=>{bk.remove();document.removeEventListener("keydown",esc2)},esc2=e=>{if(e.key==="Escape")shut()};document.addEventListener("keydown",esc2);
 bk.onclick=e=>{if(e.target===bk||e.target.dataset.odx!==undefined)shut();const a=e.target.closest&&e.target.closest("a.ono");if(a){e.preventDefault();odShow(a.dataset.ono,a.dataset.due)}};
 (async()=>{let d;try{d=await call("order_detail",{no,due})}catch(x){const b=document.getElementById("odb");if(b)b.innerHTML=`<p class="empty">Could not load: ${esc(x.message)}</p>`;return}
  const o=orderOf(no,due,d),c=d.closure,m=d.measurement,x=o.extra,e=o.e,sx=c?c.action.toUpperCase():m?"READY TO CLOSE":x&&!x.chk?"OPEN":L.items(M,o).length?"OPEN":"NO CHECKLIST",pr=procOf(o),pv=prevOf(o);
  const eqf=[["Equipment ID",e.id],["Equipment",e.name],["Type",e.type],["Location",e.loc],["Make / model",e.make],["Rating",e.rating],["Criticality",e.crit],["Status",e.status],["Installation date",e.install?dmy(e.install):""],["Schedule start",e.start?dmy(e.start):""],["Remarks",e.remarks]];
  const odf=[["Order type",x?(x.otype?x.otype+" - "+(OTYPES[x.otype]||""):KL[x.kind]):"Scheduled maintenance"],["Frequency",x&&x.kind!=="resched"?"":o.freq],["Due date",dmy(due)],["Status",sx]];
  const xf=x?[["Kind",KL[x.kind]||x.kind],["Job title",x.title],["Description",x.desc],["Created by",bn(x.by)],["From order",x.src]]:[];
  const b=document.getElementById("odb");if(!b)return;
  b.innerHTML=`<p>${chip(sx)}</p><h3>Equipment details</h3><div class="grid">${eqf.map(([a,v])=>kv(a,v)).join("")}</div>
  <h3>Order details</h3><div class="grid">${odf.filter(r=>r[1]!=="").map(([a,v])=>a==="Status"?`<div><span>${a}</span>${chip(v)}</div>`:kv(a,v)).join("")}${xf.filter(r=>r[1]).map(([a,v])=>a==="From order"?`<div><span>${a}</span>${ol(v,prevOf(o)?prevOf(o).due:due)}</div>`:kv(a,v)).join("")}${closeInfo(c,m)}</div>
  <h3>Procedure</h3>${pr?`<div class="pproc">${esc(pr)}</div>`:`<p class="empty">No procedure has been entered for ${esc(e.type||"this equipment")}${o.freq&&!(x&&!x.chk)?" / "+esc(o.freq):""}.</p>`}
  <details id="odck"><summary>Checklist items</summary><div class="wrap">${ckTbl(o,m)}</div></details>
  <details id="odlast"><summary>Last order details</summary><div id="odlb"><p class="empty">${pv?"Loading...":"No earlier order found for this equipment and frequency."}</p></div></details>`;
  const dl=document.getElementById("odlast");let got=false;dl.addEventListener("toggle",async()=>{if(!dl.open||got||!pv)return;got=true;const lb=document.getElementById("odlb");
   try{const l=await call("order_detail",{no:pv.no,due:pv.due}),lo=orderOf(pv.no,pv.due,l);lb.innerHTML=`<div class="grid">${kv("Order no.","")}${[["Due date",dmy(pv.due)]].map(([a,v])=>kv(a,v)).join("")}${closeInfo(l.closure,l.measurement)}</div>`.replace(kv("Order no.",""),`<div><span>Order no.</span>${ol(pv.no,pv.due)}</div>`)+(l.measurement?`<div class="wrap">${ckTbl(lo,l.measurement)}</div>`:`<p class="empty">No checklist was recorded for this order.</p>`)}catch(y){got=false;lb.innerHTML=`<p class="empty">Could not load: ${esc(y.message)}</p>`}})})()}
document.addEventListener("click",e=>{const a=e.target.closest&&e.target.closest("a.ono");if(a&&!a.closest("#odlg")){e.preventDefault();odShow(a.dataset.ono,a.dataset.due)}});
const PH=t=>`<div class="phead"><b>${esc(UN)} Maintenance Management Portal</b><span>${t}</span><small>Printed ${new Date().toLocaleString("en-GB")} by ${esc(NM)}</small></div>`;
const PB=`<div class="bar noprint"><button class="ghost" data-print>Print</button></div>`;
window.onbeforeprint=()=>document.querySelectorAll("details").forEach(d=>d.open=true);
const TM=/^([01]\d|2[0-3]):[0-5]\d$/,tkey=no=>"cmmsT:"+no;
const tget=no=>{try{return JSON.parse(localStorage[tkey(no)]||"{}")}catch(_){return{}}};
const tset=(no,k,v)=>{try{const o=tget(no);o[k]=v;localStorage[tkey(no)]=JSON.stringify(o)}catch(_){}};
const dur=(s,e)=>{if(!TM.test(s||"")||!TM.test(e||""))return"";const m=((+e.slice(0,2)*60+ +e.slice(3))-(+s.slice(0,2)*60+ +s.slice(3))+1440)%1440;return Math.floor(m/60)+" h "+String(m%60).padStart(2,"0")+" min"};
const tcells=(o,c)=>c?`<td>${esc(c.start||"")}</td><td>${esc(c.end||"")}</td>`:`<td><input type="time" data-st value="${esc(tget(o.no).s||"")}"${R==="mgmt"?" disabled":""}></td><td><input type="time" data-en value="${esc(tget(o.no).e||"")}"${R==="mgmt"?" disabled":""}></td>`;
const timeSaver=list=>e=>{const t=e.target,tr=t.closest("tr"),o=tr&&list[tr.dataset.i];if(!o)return;if(t.matches("[data-st]"))tset(o.no,"s",t.value);else if(t.matches("[data-en]"))tset(o.no,"e",t.value)};
const readTimes=(tr,a)=>{const s=tr.querySelector("[data-st]")?.value||"",e=tr.querySelector("[data-en]")?.value||"";return a==="Closed"&&!(TM.test(s)&&TM.test(e))?null:{start:s,end:e}};
const chip=s=>`<span class="chip ${s.replace(/ /g,"_")}">${s}</span>`;
const bars=l=>{const m=Math.max(1,...l.map(x=>x[1]));return l.map(([a,n])=>`<div class="bar2"><span>${a}</span><i style="width:${n/m*100}%"></i><em>${n}</em></div>`).join("")};
const go=r=>{route=r;location.hash=r;draw()};
function draw(){if(!M)return;if(!ROUTES.some(r=>r[0]===route))route="dashboard";$("#nav").innerHTML=ROUTES.map(([k,n])=>`<button data-r="${k}" class="${k===route?"on":""}">${n}</button>`).join("");
 const v=$("#view");v.oninput=v.onchange=null;v.onclick=e=>{if(e.target.dataset.print!==undefined)window.print()};(V[route]||V.dashboard)()}
$("#nav").onclick=e=>{if(e.target.dataset.r){fromClosing=false;go(e.target.dataset.r)}};
$("#refresh").onclick=()=>load().then(()=>toast("Refreshed.")).catch(e=>toast(e.message,1));

const COL={blue:"#2f7fd1",green:"#2e9e6b",amber:"#e09a1a",red:"#d9473f",violet:"#7a5bd0",teal:"#1aa3b5",slate:"#6b7c8a"};
const CC={High:COL.red,Medium:COL.amber,Low:COL.green};
const by=(a,f)=>{const m={};a.forEach(x=>{const k=f(x)||"Not set";m[k]=(m[k]||0)+1});return Object.entries(m).sort((x,y)=>y[1]-x[1])};
const hb=(l,c)=>{const m=Math.max(1,...l.map(x=>x[1]));return l.map(([a,n],i)=>`<div class="bar2"><span title="${esc(a)}">${esc(a)}</span><i style="width:${n/m*100}%;background:${typeof c==="function"?c(a,i):c}"></i><em>${n}</em></div>`).join("")||`<p class="empty">No orders.</p>`};
const donut=(parts,mid)=>{const tot=parts.reduce((a,p)=>a+p[1],0)||1;let off=0;return`<svg viewBox="0 0 120 120" class="donut"><circle cx="60" cy="60" r="46" fill="none" stroke="var(--line)" stroke-width="16"/>${parts.map(([n,v,c])=>{const len=v/tot*289;const e=`<circle cx="60" cy="60" r="46" fill="none" stroke="${c}" stroke-width="16" stroke-dasharray="${len} ${289-len}" stroke-dashoffset="${-off}" transform="rotate(-90 60 60)"/>`;off+=len;return e}).join("")}<text x="60" y="62" text-anchor="middle" class="dn">${mid}</text><text x="60" y="78" text-anchor="middle" class="dl">complete</text></svg>`};
const card=(t,body,c)=>`<section class="dc" style="--c:${c||COL.teal}"><h3>${t}</h3>${body}</section>`;
V.dashboard=()=>{const os=ordersOn(TD),tm=ordersOn(TD+1),n=k=>os.filter(o=>st(o)===k).length,closed=n("CLOSED"),def=n("DEFERRED"),ready=n("READY TO CLOSE"),open=os.length-closed-def,pct=os.length?Math.round((closed+def)/os.length*100):0;
 const wk=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],days=[...Array(7)].map((_,i)=>[wk[new Date((TD+i)*864e5).getUTCDay()]+" "+L.iso(TD+i).slice(8),ordersOn(TD+i).length,i===0]),mx=Math.max(1,...days.map(d=>d[1]));
 const kp=(v,l,c,sub)=>`<div class="kpi" style="--c:${c}"><b>${v}</b><span>${l}</span>${sub?`<small>${sub}</small>`:""}</div>`;
 const hr=new Date().getHours(),act=M.equipment.filter(e=>e.status!=="Inactive").length;
 const hi=os.filter(o=>o.e.crit==="High"&&!cl[o.no]).slice(0,8),rec=Object.values(cl).sort((a,b)=>String(b.at).localeCompare(String(a.at))).slice(0,8);
 $("#view").innerHTML=`<p class="greet">${hr<12?"Good morning":hr<17?"Good afternoon":"Good evening"}, ${esc(NM)}. Here is the maintenance picture for ${L.iso(TD).split("-").reverse().join("/")}.</p>
 <div class="kpis">${kp(os.length,"Due today",COL.blue,`${Object.keys(by(os,o=>o.e.loc)).length} locations`)}${kp(closed,"Closed",COL.green,pct+"% of today’s orders done")}${kp(def,"Deferred",COL.amber)}${kp(open,"Still open",COL.red,`${ready} ready to close`)}${kp(Object.keys(ms).length,"Checklists saved",COL.teal,"today")}${kp(tm.length,"Due tomorrow",COL.violet,`${tm.filter(o=>o.e.crit==="High").length} high priority`)}</div>
 <div class="dgrid">
 ${card("Completion today",`<div class="dflex">${donut([["Closed",closed,COL.green],["Deferred",def,COL.amber],["Open",open,COL.red]],pct+"%")}<ul class="leg"><li><i style="background:${COL.green}"></i>Closed <b>${closed}</b></li><li><i style="background:${COL.amber}"></i>Deferred <b>${def}</b></li><li><i style="background:${COL.red}"></i>Open <b>${open}</b></li></ul></div>`,COL.green)}
 ${card("Orders due, next 7 days",`<div class="cols">${days.map(([d,v,t])=>`<div><em>${v}</em><i style="height:${Math.max(3,v/mx*130)}px;background:${t?COL.blue:COL.violet}"></i><span>${d}</span></div>`).join("")}</div>`,COL.violet)}
 ${card("Today by criticality",["High","Medium","Low"].map(k=>{const t=os.filter(o=>o.e.crit===k),d=t.filter(o=>cl[o.no]).length;return`<div class="stk"><span>${k}</span><div style="--c:${CC[k]}"><i style="width:${t.length?d/t.length*100:0}%"></i></div><em>${d}/${t.length}</em></div>`}).join("")+`<p class="hint">Done / due, by criticality</p>`,COL.red)}
 ${card("Today by frequency",hb(by(os,o=>o.freq),COL.blue),COL.blue)}
 ${card("Today by location",hb(by(os,o=>o.e.loc).slice(0,7),COL.teal),COL.teal)}
 ${card("Today by equipment type",hb(by(os,o=>o.e.type),(a,i)=>[COL.violet,COL.amber,COL.green,COL.blue,COL.red,COL.teal,COL.slate][i%7]),COL.amber)}
 ${card("High priority, still open",hi.length?`<ul class="lst">${hi.map(o=>`<li><b>${ol(o.no,L.iso(o.due))}</b> ${esc(o.e.name)} ${chip(st(o))}</li>`).join("")}</ul>`:`<p class="empty">No high priority orders are waiting.</p>`,COL.red)}
 ${card("Recent closures today",rec.length?`<ul class="lst">${rec.map(c=>`<li><b>${ol(c.no,c.due)}</b> ${chip(c.action.toUpperCase())} <small>${esc(bn(c.by))}, ${c.at?new Date(c.at).toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}):""}</small></li>`).join("")}</ul>`:`<p class="empty">Nothing closed yet today.</p>`,COL.green)}
 ${card("Equipment register",`<div class="eq"><div><b>${M.equipment.length}</b><span>Total</span></div><div><b>${act}</b><span>Active</span></div><div><b>${M.equipment.length-act}</b><span>Inactive</span></div><div><b>${M.types.length}</b><span>Types</span></div><div><b>${Object.keys(M.areas).length}</b><span>Locations</span></div></div>`,COL.slate)}
 </div>`};

V.closing=()=>{const os=ordersOn(TD);
 $("#view").innerHTML=PH("Order closing, "+L.iso(TD).split("-").reverse().join("/"))+PB+`<div class="wrap"><table><thead><tr><th>Order no.</th><th>Equipment</th><th>Criticality</th><th>Status</th><th>Start time</th><th>End time</th><th>Remarks</th><th>Defer to</th><th class="noprint"></th></tr></thead><tbody>${os.map((o,i)=>{const s=st(o),done=!!cl[o.no];
 return`<tr data-i="${i}"><td>${ol(o.no,L.iso(o.due))}</td><td>${esc(o.e.name)}<small>${o.e.id}, ${esc(o.e.type)}, ${esc(o.e.loc)}</small>${xinfo(o)}</td><td>${esc(o.e.crit)}</td><td>${chip(s)}</td>${tcells(o,cl[o.no])}<td><input data-r value="${esc(cl[o.no]?.rem||"")}"${done?" disabled":""}></td><td>${done?(cl[o.no].newDate?dmy(cl[o.no].newDate):""):`<input type="date" data-nd min="${L.iso(TD+1)}">`}</td>
 <td class="noprint">${done?"":`${ckBtn(o)}<button data-a="Closed"${cc(o,s)?"":" disabled"}>Close</button> <button class="ghost" data-a="Deferred">Defer</button>`}</td></tr>`}).join("")||`<tr><td colspan="9" class="empty">No orders are due today.</td></tr>`}</tbody></table></div>`;
 $("#view").oninput=timeSaver(os);
 $("#view").onclick=async e=>{const a=e.target.dataset.a,tr=e.target.closest("tr");if(e.target.dataset.print!==undefined)return window.print();if(!a||!tr)return;const o=os[tr.dataset.i];if(a==="chk"){cur=o.no;fromClosing=true;go("checklist");return}
  const rem=tr.querySelector("[data-r]").value.trim();if(a==="Deferred"&&!rem)return toast("Enter a remark to defer an order.",1);const nd=tr.querySelector("[data-nd]")?.value||"";if(a==="Deferred"&&!(nd>L.iso(o.due)&&nd>=L.iso(TD)))return toast("Select the new date for the deferred order. It must be after the due date and not in the past.",1);const tm=readTimes(tr,a);if(!tm)return toast("Enter the start time and end time before closing the order.",1);e.target.disabled=true;
  try{const result=await call("closure",{rec:{no:o.no,due:L.iso(o.due),eq:o.e.id,name:o.e.name,freq:o.freq,action:a,on:L.iso(TD),rem,start:tm.start,end:tm.end,newDate:a==="Deferred"?nd:undefined}});try{localStorage.removeItem(tkey(o.no))}catch(_){}toast(result.attentionNotificationPending?`${o.no} closed, but the Attention alert could not be saved. Please retry.`:result.attentionNotification?`${o.no} closed. Attention notification and a corrective order (due today) created.`:`${o.no} ${a==="Closed"?"closed.":"deferred to "+dmy(nd)+". A new order was created for that date."}`);await load()}catch(x){toast(x.message,1);e.target.disabled=false}}};

const res=i=>!i.ok?"":i.ok==="OK"?"PASS":i.notes.trim().length>20?"ATTENTION":"FAIL";
V.checklist=()=>{const os=ordersOn(TD),o=os.find(x=>x.no===cur)||(pastOrder&&pastOrder.no===cur?pastOrder:null),done=o&&(ms[o.no]||cl[o.no]||RG.ms[o.no]||RG.cl[o.no]);items=o&&!done?L.items(M,o).map(r=>({r,reading:"",ok:"",notes:""})):[];
 $("#view").innerHTML=`<label class="pick">Maintenance order <select id="ord"><option value="">Select the order number</option>${[...os,...(pastOrder&&!os.some(x=>x.no===pastOrder.no)?[pastOrder]:[])].map(x=>`<option${x.no===cur?" selected":""}>${x.no}</option>`).join("")}</select></label>`+
 (o?`<div class="grid">${[["EQ ID",o.e.id],["Equipment",o.e.name],["Type",o.e.type],["Frequency",o.freq],["Location",o.e.loc],["Criticality",o.e.crit],["Status",st(o)]].map(([a,b])=>`<div><span>${a}</span>${esc(b)}</div>`).join("")}</div>`:"")+
 (o&&procOf(o)?`<details class="proc" open><summary><b>Procedure</b></summary><div class="pproc">${esc(procOf(o))}</div></details>`:"")+(done?`<p class="empty">The checklist for this order is already saved.</p>`:o&&o.extra&&!o.extra.chk?`<p class="empty">This order has no checklist. Close it from Order closing.</p>`:o&&!items.length?`<p class="empty">No active checklist items for ${esc(o.e.type)} / ${esc(o.freq)}.</p>`:o?`<div class="wrap"><table><thead><tr><th>Seq.</th><th>Check item</th><th>Actual reading</th><th>Mandatory</th><th>Acceptance criteria</th><th>OK / NOT OK</th><th>Notes</th><th>Result</th></tr></thead><tbody>${items.map(({r},i)=>`<tr data-i="${i}"><td>${r.seq}</td><td>${esc(r.item)}<small>${esc(r.id)}</small></td><td>${r.readReq==="Yes"?`<input data-k="reading" size="7"> ${esc(r.unit)}`:"Not required"}</td><td>${esc(r.mand)}</td><td>${esc(r.criteria)}</td><td><select data-k="ok"><option></option><option>OK</option><option>NOT OK</option></select></td><td><input data-k="notes" placeholder="Required if NOT OK (more than 20 characters)"></td><td class="r"></td></tr>`).join("")}</tbody></table></div><div class="bar"><b id="ckState"></b><button id="saveCk" disabled>Save checklist</button></div>`:"");
 const upd=()=>{items.forEach((it,i)=>{const t=res(it),c=$("#view").querySelectorAll("tbody .r")[i];if(c)c.innerHTML=t?chip(t):""});const rs=items.map(res),n=rs.filter(x=>x==="PASS"||x==="ATTENTION").length,ok=items.length&&n===items.length;
  const s=$("#ckState");if(s){s.textContent=ok?(rs.includes("ATTENTION")?"Complete, with attention items":"Complete, all pass"):`${n} of ${items.length} items done`;$("#saveCk").disabled=!ok}};
 $("#view").onchange=$("#view").oninput=e=>{if(e.target.id==="ord"){if(e.type==="change"){cur=e.target.value;fromClosing=false;V.checklist()}return}const tr=e.target.closest("tr"),k=e.target.dataset.k;if(tr&&k){items[tr.dataset.i][k]=e.target.value;upd()}};
 $("#view").onclick=async e=>{if(e.target.id!=="saveCk")return;e.target.disabled=true;
  try{const r=await call("measurement",{rec:{no:o.no,due:L.iso(o.due),eq:o.e.id,name:o.e.name,type:o.e.type,freq:o.freq,loc:o.e.loc,crit:o.e.crit,on:L.iso(TD),
   items:items.map(({r,reading,ok,notes})=>({id:r.id,item:r.item,unit:r.unit||"",reading:reading===""?"":isNaN(reading)?reading:Number(reading),mand:r.mand,criteria:r.criteria,ok,result:res({ok,notes}),notes:notes.trim()}))}});
   if(r.duplicate)toast("This order’s checklist is already saved.",1);else toast(`Checklist saved for ${o.no}.`);const back=pastOrder&&pastOrder.no===cur;cur="";if(back){pastOrder=null;await load();RG.done=false;go("report")}else if(fromClosing){fromClosing=false;route="closing";location.hash="closing";await load()}else await load()}catch(x){toast(x.message,1);e.target.disabled=false}};
 if(items.length)upd()};

async function rload(){try{const d=await call("range",{from:L.iso(TD-RG.days),to:L.iso(TD-1)});RG.cl=Object.fromEntries(d.closures.map(c=>[c.no,c]));RG.ms=Object.fromEntries(d.measurements.map(m=>[m.no,1]))}catch(x){toast(x.message,1)}RG.done=true;if(route==="report")draw()}
const dmy=x=>String(x).split("-").reverse().join("/");
V.report=()=>{if(!RG.done){rload();$("#view").innerHTML=`<p class="empty">Loading the closure report...</p>`;return}
 const all=[];for(let t=TD-RG.days;t<TD;t++)ordersOn(t).forEach(o=>all.push(o));
 const cnt=k=>all.filter(o=>st(o)===k).length,closed=cnt("CLOSED"),def=cnt("DEFERRED"),pend=all.length-closed-def,late=all.filter(o=>{const c=RG.cl[o.no];return c&&c.action==="Closed"&&c.on>L.iso(o.due)}).length;
 const f=all.filter(o=>rf==="All"||(rf==="Pending"?!RG.cl[o.no]:st(o)===rf.toUpperCase())).sort((a,b)=>a.due-b.due);
 const kp=(v,l,c)=>`<div class="kpi" style="--c:${c}"><b>${v}</b><span>${l}</span></div>`,v=$("#view");
 v.innerHTML=PH(`Closure report, ${dmy(L.iso(TD-RG.days))} to ${dmy(L.iso(TD-1))}`)+`<div class="kpis">${kp(all.length,"Orders due",COL.blue)}${kp(closed,"Closed",COL.green)}${kp(def,"Deferred",COL.amber)}${kp(pend,"Still pending",COL.red)}${kp(late,"Closed late",COL.violet)}</div>
 <div class="bar noprint"><label>Period <select id="rd"><option value="7"${RG.days===7?" selected":""}>Last 7 days</option><option value="14"${RG.days===14?" selected":""}>Last 14 days</option></select></label>
 <label>Show <select id="rfl">${["Pending","Closed","Deferred","All"].map(x=>`<option${x===rf?" selected":""}>${x}</option>`).join("")}</select></label><button class="ghost" data-print>Print</button></div>
 <p class="hint">${f.length} order(s) shown. Orders before today are listed from the current schedule.</p>`+
 tbl(["Order no.","Due date","Overdue","Equipment","Criticality","Status","Start time","End time","Closed on / by","Remarks","Defer to",'<span class="noprint"></span>'],f.map((o,i)=>{const c=RG.cl[o.no],s2=st(o);
  return`<tr data-i="${i}"><td>${ol(o.no,L.iso(o.due))}</td><td>${dmy(L.iso(o.due))}</td><td>${c?"":TD-o.due+" d"}</td><td>${esc(o.e.name)}<small>${o.e.id}, ${esc(o.e.type)}, ${esc(o.e.loc)}</small>${xinfo(o)}</td><td>${esc(o.e.crit)}</td><td>${chip(s2)}</td>${tcells(o,c)}<td>${c?`${dmy(c.on)} by ${esc(bn(c.by))}${c.action==="Closed"&&c.on>L.iso(o.due)?" (late)":""}`:""}</td><td><input data-r value="${esc(c?.rem||"")}"${c||R==="mgmt"?" disabled":""}></td><td>${c?(c.newDate?dmy(c.newDate):""):`<input type="date" data-nd min="${L.iso(TD)}"${R==="mgmt"?" disabled":""}>`}</td>
  <td class="noprint">${c||R==="mgmt"?"":`${ckBtn(o)}<button data-a="Closed"${cc(o,s2)?"":" disabled"}>Close</button> <button class="ghost" data-a="Deferred">Defer</button>`}</td></tr>`}));
 v.oninput=timeSaver(f);
 v.onchange=e=>{if(e.target.id==="rd"){RG.days=+e.target.value;RG.done=false;V.report()}else if(e.target.id==="rfl"){rf=e.target.value;V.report()}};
 v.onclick=async e=>{if(e.target.dataset.print!==undefined)return window.print();const a=e.target.dataset.a,tr=e.target.closest("tr");if(!a||!tr)return;const o=f[tr.dataset.i];
  if(a==="chk"){cur=o.no;pastOrder=o;go("checklist");return}
  const rem=tr.querySelector("[data-r]").value.trim();if(a==="Deferred"&&!rem)return toast("Enter a remark to defer an order.",1);const nd=tr.querySelector("[data-nd]")?.value||"";if(a==="Deferred"&&!(nd>L.iso(o.due)&&nd>=L.iso(TD)))return toast("Select the new date for the deferred order. It must be after the due date and not in the past.",1);const tm=readTimes(tr,a);if(!tm)return toast("Enter the start time and end time before closing the order.",1);e.target.disabled=true;
  try{await call("closure",{rec:{no:o.no,due:L.iso(o.due),eq:o.e.id,name:o.e.name,freq:o.freq,action:a,on:L.iso(TD),rem,start:tm.start,end:tm.end,newDate:a==="Deferred"?nd:undefined}});try{localStorage.removeItem(tkey(o.no))}catch(_){}toast(`${o.no} ${a==="Closed"?"closed.":"deferred to "+dmy(nd)+". A new order was created for that date."}`);await rload()}catch(x){toast(x.message,1);e.target.disabled=false}}};

V.tomorrow=()=>{const os=ordersOn(TD+1);
 $("#view").innerHTML=PH("Tomorrow’s maintenance orders, "+L.iso(TD+1).split("-").reverse().join("/"))+PB+`<p class="hint">${os.length} order(s) due on ${L.iso(TD+1).split("-").reverse().join("/")}</p><div class="wrap"><table><thead><tr><th>Sl.</th><th>Order no.</th><th>Equipment</th><th>Type</th><th>Location</th><th>Criticality</th><th>Frequency</th></tr></thead><tbody>${os.map((o,i)=>`<tr><td>${i+1}</td><td>${ol(o.no,L.iso(o.due))}</td><td>${esc(o.e.name)}<small>${o.e.id}</small>${xinfo(o)}</td><td>${esc(o.e.type)}</td><td>${esc(o.e.loc)}</td><td>${esc(o.e.crit)}</td><td>${o.freq}</td></tr>`).join("")||`<tr><td colspan="7" class="empty">No orders due tomorrow.</td></tr>`}</tbody></table></div>`};

const KPI={P:"Production",Q:"Quality",C:"Cost",D:"Delivery",S:"Safety",M:"Morale"},NT=["Planned","Breakdown","Improvement","Interruption","Attention"];
let nm=L.iso(TD).slice(0,7),nl=null,nf={type:"",area:"",q:""};
async function nload(){try{nl=(await call("notif_list",{month:nm})).list}catch(x){toast(x.message,1);nl=[]}if(route==="notifications")draw()}
const nfilt=()=>nl.filter(n=>(!nf.type||n.type===nf.type)&&(!nf.area||n.area===nf.area)&&(!nf.q||[n.no,n.title,n.desc,n.eqName,n.eq,n.team].join(" ").toLowerCase().includes(nf.q.toLowerCase()))).sort((a,b)=>String(b.at).localeCompare(String(a.at)));
const delayParts=n=>{const total=Number(n.delay||0);return{h:Number.isFinite(Number(n.delayHours))?Number(n.delayHours):Math.floor(total/60),m:Number.isFinite(Number(n.delayMinutes))?Number(n.delayMinutes):total%60}};
const delayText=n=>{const d=delayParts(n);return`${d.h} h ${String(d.m).padStart(2,"0")} min`};
const nrows=()=>{const f=nfilt(),dl=f.reduce((a,n)=>a+Number(n.delayHours??Math.floor(Number(n.delay||0)/60))*60+Number(n.delayMinutes??(Number(n.delay||0)%60)),0),dh=Math.floor(dl/60),dm=dl%60;
 return`<p class="hint">${f.length} notification(s)${f.some(n=>n.type==="Breakdown")?` | Total breakdown delay: ${dh} h ${String(dm).padStart(2,"0")} min`:""}</p>`+tbl(["Notification no.","Date","Type","Area","Equipment","Title and description","Delay (h : min)","KPIs","Team members","Logged by"],f.map(n=>`<tr><td class="mono">${esc(n.no||"")}</td><td class="mono">${n.date.split("-").reverse().join("/")}</td><td>${chip(n.type.toUpperCase())}</td><td>${esc(n.area)}</td><td>${esc(n.eqName)}<small>${esc(n.eq)}</small></td><td><b>${esc(n.title)}</b><br>${esc(n.desc)}</td><td>${n.type==="Breakdown"?delayText(n):""}</td><td>${(n.kpis||[]).map(k=>`<span class="chip KPIC" title="${KPI[k]}">${k}</span>`).join(" ")}</td><td>${esc(n.team)}</td><td>${esc(bn(n.by))}</td></tr>`))};
V.notifications=()=>{if(nl===null){nload();$("#view").innerHTML=`<p class="empty">Loading notifications...</p>`;return}
 const areas=Object.keys(M.areas),v=$("#view");
 v.innerHTML=PH("Notifications, "+nm.split("-").reverse().join("/"))+`<section class="dc noprint" style="--c:#2f7fd1"><h3>Log a notification</h3><div class="nform">
 <label>Date <input type="date" id="nd" value="${L.iso(TD)}"></label>
 <label>Area <select id="na"><option value="">Select area</option>${areas.map(a=>`<option>${esc(a)}</option>`).join("")}</select></label>
 <label>Equipment <select id="ne"><option value="">Select area first</option></select></label>
 <label>Notification type <select id="nt"><option value="">Select type</option>${NT.filter(t=>t!=="Attention").map(t=>`<option>${t}</option>`).join("")}</select></label>
 <label class="wide">Heading / title <input id="ntl" maxlength="120"></label>
 <label class="wide">Description <textarea id="nds" rows="4" maxlength="2000"></textarea></label>
 <div id="ndw" class="delay-fields wide" hidden><label>Breakdown duration - Hours <input type="number" id="ndh" min="0" step="1" value="0" inputmode="numeric" placeholder="Hours"></label><label>Minutes <input type="number" id="ndm" min="0" max="59" step="1" value="0" inputmode="numeric" placeholder="00"></label><small>Enter the breakdown duration in hours and minutes (e.g. 2 hours 30 minutes).</small></div>
 <fieldset id="nkw" class="wide" hidden><legend>KPIs affected</legend>${Object.entries(KPI).map(([k,n])=>`<label class="pill"><input type="checkbox" value="${k}"> ${k} - ${n}</label>`).join("")}</fieldset>
 <label class="wide">Team members <input id="ntm" maxlength="300" placeholder="Names separated by commas"></label></div>
 <div class="bar"><button id="nsave">Save notification</button></div></section>
 <div class="bar noprint"><label>Month <input type="month" id="nmth" value="${nm}"></label><label>Type <select id="fT"><option value="">All</option>${NT.map(t=>`<option${nf.type===t?" selected":""}>${t}</option>`).join("")}</select></label>
 <label>Area <select id="fA"><option value="">All</option>${areas.map(a=>`<option${nf.area===a?" selected":""}>${esc(a)}</option>`).join("")}</select></label><label>Search <input id="fQ" value="${esc(nf.q)}"></label><button class="ghost" data-print>Print</button></div><div id="nlist">${nrows()}</div>`;if(R==="mgmt")v.querySelector("section.dc.noprint")?.remove();
 v.oninput=v.onchange=e=>{const id=e.target.id;
  if(id==="nt"){$("#ndw").hidden=e.target.value!=="Breakdown";$("#nkw").hidden=e.target.value!=="Improvement"}
  else if(id==="na"){$("#ne").innerHTML=e.target.value?`<option value="">Select equipment</option>`+M.equipment.filter(x=>x.loc===e.target.value&&x.status!=="Inactive").map(x=>`<option value="${esc(x.id)}">${esc(x.id)} - ${esc(x.name)}</option>`).join(""):`<option value="">Select area first</option>`}
  else if(id==="nmth"&&e.type==="change"&&e.target.value){nm=e.target.value;nl=null;V.notifications()}
  else if(id==="fT"||id==="fA"||id==="fQ"){nf={type:$("#fT").value,area:$("#fA").value,q:$("#fQ").value};$("#nlist").innerHTML=nrows()}};
 v.onclick=async e=>{if(e.target.dataset.print!==undefined)return window.print();if(e.target.id!=="nsave")return;
  const g=i=>$("#"+i).value.trim(),type=g("nt"),eq=M.equipment.find(x=>x.id===g("ne")),kp=[...v.querySelectorAll("#nkw input:checked")].map(x=>x.value);
  if(!g("na")||!eq||!type||!g("ntl")||!g("nds"))return toast("Select area, equipment and type, and enter a title and description.",1);
  const delayHours=type==="Breakdown"?Number(g("ndh")):0,delayMinutes=type==="Breakdown"?Number(g("ndm")):0;
   if(type==="Breakdown"&&(g("ndh")===""||g("ndm")===""||!Number.isInteger(delayHours)||delayHours<0||!Number.isInteger(delayMinutes)||delayMinutes<0||delayMinutes>59))return toast("Enter valid breakdown hours and minutes (minutes must be 0-59).",1);
  if(type==="Improvement"&&!kp.length)return toast("Select at least one KPI.",1);
  e.target.disabled=true;try{const r=await call("notif_add",{rec:{date:g("nd"),area:g("na"),eq:eq.id,eqName:eq.name,type,title:g("ntl"),desc:g("nds"),delayHours,delayMinutes,delay:delayHours*60+delayMinutes,kpis:kp,team:g("ntm")}});
   toast(`Notification ${r.no} saved.`);nm=g("nd").slice(0,7);nl=null;V.notifications()}catch(x){toast(x.message,1);e.target.disabled=false}}};

const tbl=(h,rows)=>`<div class="wrap"><table><thead><tr>${h.map(x=>`<th>${x}</th>`).join("")}</tr></thead><tbody>${rows.join("")||`<tr><td colspan="${h.length}" class="empty">No records.</td></tr>`}</tbody></table></div>`;
const histBar=()=>`<div class="bar noprint"><label>Date <input type="date" id="hd" value="${hd}"></label><button data-load>Load</button><button class="ghost" data-print>Print</button></div>`;
A.closure=()=>PH("Closure history, "+hd.split("-").reverse().join("/"))+histBar()+(hist?tbl(["Order no.","Due","EQ ID","Equipment","Frequency","Action","Start time","End time","Duration","Closed on","Closed by","Remarks","Defer to"],hist.closures.map(c=>`<tr><td>${ol(c.no,c.due)}</td><td>${c.due}</td><td>${c.eq}</td><td>${esc(c.name)}</td><td>${c.freq}</td><td>${chip(c.action.toUpperCase())}</td><td>${esc(c.start||"")}</td><td>${esc(c.end||"")}</td><td>${dur(c.start,c.end)}</td><td>${c.on}</td><td>${esc(bn(c.by))}</td><td>${esc(c.rem)}</td><td>${c.newDate?dmy(c.newDate):""}</td></tr>`)):`<p class="empty">Pick a date and click Load.</p>`);
A.orders=()=>PH("Maintenance order history, "+hd.split("-").reverse().join("/"))+histBar()+(hist?hist.measurements.map(m=>`<details><summary><b>${ol(m.no,m.due)}</b> ${esc(m.name)} (${m.freq}), recorded by ${esc(bn(m.by))} on ${m.on}</summary>${tbl(["Check item","Reading","Mandatory","OK / NOT OK","Result","Notes"],m.items.map(i=>`<tr><td>${esc(i.item)}</td><td>${esc(i.reading)} ${esc(i.unit)}</td><td>${i.mand}</td><td>${i.ok}</td><td>${chip(i.result)}</td><td>${esc(i.notes)}</td></tr>`))}</details>`).join("")||`<p class="empty">No records for this date.</p>`:`<p class="empty">Pick a date and click Load.</p>`);
const sel=(k,i,v,l)=>`<select data-k="${k}" data-i="${i}">${l.map(x=>`<option${x===v?" selected":""}>${esc(x)}</option>`).join("")}</select>`;

/* EQUIPMENT DETAILS WITH AREA AND TYPE FILTERS */
let eqAreaFilter="",eqTypeFilter="";

A.equip=()=>{
    const filtered=M.equipment
        .map((e,i)=>({e,i}))
        .filter(({e})=>
            (!eqAreaFilter || e.loc===eqAreaFilter) &&
            (!eqTypeFilter || e.type===eqTypeFilter)
        );

    const areaOptions=Object.keys(M.areas)
        .map(a=>`<option value="${esc(a)}"${a===eqAreaFilter?" selected":""}>${esc(a)}</option>`)
        .join("");

    const typeOptions=M.types
        .map(t=>`<option value="${esc(t)}"${t===eqTypeFilter?" selected":""}>${esc(t)}</option>`)
        .join("");

    const filterLine=`
        <div class="bar noprint">
            <label>
                Area
                <select id="eqAreaFilter">
                    <option value=""${eqAreaFilter===""?" selected":""}>All Areas</option>
                    ${areaOptions}
                </select>
            </label>
            <label>
                Equipment Type
                <select id="eqTypeFilter">
                    <option value=""${eqTypeFilter===""?" selected":""}>All Types</option>
                    ${typeOptions}
                </select>
            </label>
            <span class="hint">Showing ${filtered.length} of ${M.equipment.length} equipment records</span>
        </div>
    `;

    const equipmentRows=filtered.map(({e,i})=>`
        <tr>
            <td class="mono">${esc(e.id)}</td>
            <td><input data-k="name" data-i="${i}" value="${esc(e.name)}"></td>
            <td>${sel("type",i,e.type,["",...M.types])}</td>
            <td>${sel("loc",i,e.loc,["",...Object.keys(M.areas)])}</td>
            <td>${sel("status",i,e.status,["Active","Inactive"])}</td>
            <td>${sel("crit",i,e.crit,["","High","Medium","Low"])}</td>
            <td><input type="date" data-k="start" data-i="${i}" value="${esc(e.start||"")}"></td>
            <td><select data-k="day" data-i="${i}"><option value="">By area</option>${DAYS.map((d,j)=>`<option value="${j+1}"${+e.day===j+1?" selected":""}>${d.slice(0,3)}</option>`).join("")}</select></td>
            <td><input data-k="make" data-i="${i}" value="${esc(e.make)}"></td>
            <td><input data-k="rating" data-i="${i}" value="${esc(e.rating)}"></td>
            <td><input data-k="remarks" data-i="${i}" value="${esc(e.remarks)}"></td>
        </tr>
    `);

    return `
        <div class="bar">
            <button data-add>Add equipment</button>
            <button data-save>Save changes</button>
            <span class="hint">Set an equipment to Inactive instead of deleting it.</span>
        </div>
        ${filterLine}
    ` + (
        equipmentRows.length
            ? tbl(
                ["EQ ID","Name","Type","Location","Status","Criticality","Schedule start","Day","Make / model","Rating","Remarks"],
                equipmentRows
            )
            : `<p class="empty">No equipment matches the selected filters.</p>`
    );
};

const DAYS=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
let BAL=null,balFrom="";
function balPreview(){const E=L.dn(balFrom),H=730,lv=L.level(M,E),M2=JSON.parse(JSON.stringify(M));M2.settings.balanceFrom=balFrom;M2.equipment.forEach(e=>{if(lv.day[e.id]!==undefined)e.day=lv.day[e.id]});BAL={from:balFrom,E,lv,before:L.series(M,E,H),after:L.series(M2,E,H)}}
const bst=a=>{const y=a.slice(365),av=y.reduce((s,x)=>s+x,0)/y.length;return{av,min:Math.min(...y),max:Math.max(...y),hi:y.filter(x=>x>1.5*av).length}};
const balBars=(a,E,mx,c)=>`<div class="cols">${a.slice(0,28).map((v,k)=>`<div><em>${v}</em><i style="height:${Math.max(3,v/mx*110)}px;background:${c}"></i><span>${L.iso(E+k).slice(8)}</span></div>`).join("")}</div>`;
const balUI=()=>{if(!balFrom)balFrom=M.settings.balanceFrom||L.iso(TD+1);let h=`<h3>Level the daily workload</h3><p class="hint">One rule for every plant. The areas are taken in the order of the numbers in "Assigned day for each location" below, starting with the weekday of the effective date. Each area stays together on a day; when a day is full, the rest of the area moves on to the next day, so all 7 days carry about the same number of orders. Orders before the effective date stay as they are.${M.settings.balanceFrom?` Levelled schedule is in use since ${dmy(M.settings.balanceFrom)}.`:" It is not switched on for this plant yet."}</p>
 <div class="bar"><label>Effective from <input type="date" id="bfrom" value="${balFrom}"${M.settings.balanceFrom?"":` min="${L.iso(TD+1)}"`}></label><button data-bprev>Preview</button>${BAL?`<button data-bapply>Apply and save</button>`:""}</div>`;
 if(BAL){const b=bst(BAL.before),a=bst(BAL.after),mx=Math.max(...BAL.before.slice(0,28),...BAL.after.slice(0,28),1),pd=BAL.lv.perDay,over=pd.filter(p=>p.areas.length>2).length;
  h+=tbl(["From year 2 (steady state)","Now","Levelled"],[["Average orders per day",b.av.toFixed(1),a.av.toFixed(1)],["Busiest day",b.max,a.max],["Quietest day",b.min,a.min],["Days above 1.5 times the average",b.hi,a.hi]].map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td><b>${r[2]}</b></td></tr>`))+
  `<h3 style="margin-top:14px">Area sequence after levelling (weekly and longer orders)</h3>`+tbl(["Day","Areas","Equipment per area"],pd.map(p=>`<tr><td>${DAYS[p.day-1]}</td><td>${p.areas.length}</td><td>${p.areas.map(x=>esc(x.area)+" ("+x.n+")").join(", ")||"-"}</td></tr>`))+
  (over?`<p class="hint">${over} day(s) would carry more than 2 areas, because the areas are too small to fill a day in this order. To change that, change the numbers in "Assigned day for each location" (areas are taken from 1 to 7) and press Preview again.</p>`:`<p class="hint">No day has more than 2 areas.</p>`)+
  `<h3 style="margin-top:14px">Orders per day, first 28 days from ${dmy(BAL.from)}: now</h3>${balBars(BAL.before,BAL.E,mx,COL.red)}<h3 style="margin-top:14px">Levelled</h3>${balBars(BAL.after,BAL.E,mx,COL.green)}<p class="hint">Nothing is changed until you press Apply and save. Daily inspections are not part of the area sequence. Around the effective date an order can come earlier or later than before; two orders of the same kind are never created right after each other.</p>`}
 return h};
A.sched=()=>balUI()+`<div class="bar" style="margin-top:22px"><button data-save>Save changes</button><span class="hint">Before the levelled schedule starts, weekly and longer maintenance for all equipment at a location falls on its assigned day. In the levelled schedule these numbers only set the order of the areas (1 to 7). Changing a day moves the next due dates, so save before using the closing pages.</span></div>
<h3>Assigned day for each location</h3>`+tbl(["Location","Assigned day"],Object.keys(M.areas).map(a=>`<tr><td>${esc(a)}</td><td><select data-area="${esc(a)}">${DAYS.map((d,i)=>`<option value="${i+1}"${+M.areas[a]===i+1?" selected":""}>${d}</option>`).join("")}</select></td></tr>`))+
`<h3 style="margin-top:24px">Frequencies for each equipment type</h3><p class="hint">Tick the frequencies each type needs. Start date and criticality are set per equipment in Equipment details.</p>`+tbl(["Type",...M.settings.freqs],M.types.map(t=>`<tr><td>${esc(t)}</td>${M.settings.freqs.map((f,j)=>`<td><input type="checkbox" data-t="${esc(t)}" data-f="${j}"${(M.ticks[t]||[])[j]?" checked":""}></td>`).join("")}</tr>`));
let ct="",cf="";
A.checklist=()=>{const rows=M.library.map((r,i)=>[r,i]).filter(([r])=>(!ct||r.type===ct)&&(!cf||r.freq===cf)).sort((a,b)=>a[0].type.localeCompare(b[0].type)||M.settings.freqs.indexOf(a[0].freq)-M.settings.freqs.indexOf(b[0].freq)||a[0].seq-b[0].seq);
 const yn=(k,i,v)=>`<select data-lk="${k}" data-li="${i}"><option${v==="Yes"?" selected":""}>Yes</option><option${v==="Yes"?"":" selected"}>No</option></select>`;
 return`<div class="bar"><label>Equipment type <select id="ct"><option value="">All</option>${M.types.map(t=>`<option${t===ct?" selected":""}>${esc(t)}</option>`).join("")}</select></label><label>Frequency <select id="cf"><option value="">All</option>${M.settings.freqs.map(f=>`<option${f===cf?" selected":""}>${f}</option>`).join("")}</select></label><button data-addchk>Add item</button><button data-save>Save changes</button></div>
 <p class="hint">Choose an equipment type and a frequency to add an item to that checklist. Set Active to No to hide an item without deleting it. Changes apply to new checklists only.</p>`+(ct&&cf?`<h3>Procedure for ${esc(ct)}, ${esc(cf)}</h3><p class="hint">Shown in the order details and above the checklist for every order of this equipment type and frequency. Press Save changes after typing.</p><textarea rows="6" style="width:100%" data-proc="${esc(ct+"|"+cf)}" placeholder="Enter the procedure to follow, one step per line">${esc((M.procedures||{})[ct+"|"+cf]||"")}</textarea>`:`<p class="hint">Select an equipment type and a frequency to enter or edit its procedure.</p>`)+
 tbl(["ID","Seq.","Check item","Reading required","Unit","Acceptance criteria","Mandatory","Active",""],rows.map(([r,i])=>`<tr><td class="mono">${esc(r.id)}<small>${esc(r.type)}, ${esc(r.freq)}</small></td><td><input type="number" style="width:60px" data-lk="seq" data-li="${i}" value="${r.seq}"></td><td><input data-lk="item" data-li="${i}" value="${esc(r.item)}"></td><td>${yn("readReq",i,r.readReq)}</td><td><input style="width:70px" data-lk="unit" data-li="${i}" value="${esc(r.unit)}"></td><td><input data-lk="criteria" data-li="${i}" value="${esc(r.criteria)}"></td><td>${yn("mand",i,r.mand)}</td><td>${yn("active",i,r.active)}</td><td><button class="ghost" data-delchk="${i}">Delete</button></td></tr>`))};


V.neworder=()=>{const v=$("#view"),ex=EX.filter(x=>x.kind==="additional").sort((a,b)=>b.due.localeCompare(a.due)||String(b.at).localeCompare(String(a.at)));
 v.innerHTML=`<section class="dc noprint" style="--c:#2f7fd1"><h3>Create an additional maintenance order</h3><p class="hint">For work outside the schedule. The order has no checklist. It appears in Order closing on its due date and is closed there.</p><div class="nform">
 <label>Type of order <select id="oty"><option value="">Select type</option>${Object.entries(OTYPES).map(([k,n])=>`<option value="${k}">${k} - ${n}</option>`).join("")}</select></label>
 <label>Due date <input type="date" id="od" min="${L.iso(TD)}" value="${L.iso(TD)}"></label>
 <label>Area <select id="oa"><option value="">Select area</option>${Object.keys(M.areas).map(a=>`<option>${esc(a)}</option>`).join("")}</select></label>
 <label>Equipment <select id="oe"><option value="">Select area first</option></select></label>
 <label class="wide">Job title <input id="ot" maxlength="120"></label>
 <label class="wide">Description <textarea id="odsc" rows="3" maxlength="2000"></textarea></label></div>
 <div class="bar"><button id="osave">Create order</button></div></section>
 <h3 style="margin-top:18px">Additional orders, recent and upcoming</h3>`+tbl(["Order no.","Type","Due date","Equipment","Location","Job","Created by"],ex.map(x=>`<tr><td>${ol(x.no,x.due)}</td><td>${x.otype?esc(x.otype)+" - "+esc(OTYPES[x.otype]||""):""}</td><td>${dmy(x.due)}</td><td>${esc(x.name)}<small>${esc(x.eq)}</small></td><td>${esc(x.loc)}</td><td><b>${esc(x.title)}</b><br>${esc(x.desc||"")}</td><td>${esc(bn(x.by))}</td></tr>`));
 v.onchange=e=>{if(e.target.id==="oa")$("#oe").innerHTML=e.target.value?`<option value="">Select equipment</option>`+M.equipment.filter(x=>x.loc===e.target.value&&x.status!=="Inactive").map(x=>`<option value="${esc(x.id)}">${esc(x.id)} - ${esc(x.name)}</option>`).join(""):`<option value="">Select area first</option>`};
 v.onclick=async e=>{if(e.target.id!=="osave")return;const g=i=>$("#"+i).value.trim();
  if(!g("od")||g("od")<L.iso(TD))return toast("Select a due date from today onwards.",1);if(!g("oty"))return toast("Select the type of order.",1);if(!g("oe")||!g("ot"))return toast("Select the area and equipment, and enter a job title.",1);
  e.target.disabled=true;try{const r=await call("order_add",{rec:{otype:g("oty"),due:g("od"),eq:g("oe"),title:g("ot"),desc:g("odsc")}});toast(`Order ${r.no} created for ${dmy(g("od"))}.`);await load()}catch(x){toast(x.message,1);e.target.disabled=false}}};

/* COMPLIANCE: weekly, monthly and yearly (January to December) */
const CFROM=()=>M.settings.complianceFrom||"2026-11-01";
let cmp={tab:"weekly",date:L.iso(TD-1),month:L.iso(TD-1).slice(0,7),year:+L.iso(TD).slice(0,4)},CPC={},CD={key:"",rows:null,parts:{},err:"",done:false},cpRun=0,adminShow=null;
const MON=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],DS=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const cpClip=(a,b)=>{const lo=Math.max(a,L.dn(CFROM())),hi=Math.min(b,TD-1);return lo<=hi?[lo,hi]:null};
async function cpClosures(a,b){const r=cpClip(a,b);if(!r)return{closures:[],extras:[]};const from=L.iso(r[0]),to=L.iso(r[1]),k=from+"|"+to,h=CPC[k];if(h&&Date.now()-h.t<3e5)return h.l;const d=await call("compliance_range",{from,to});CPC[k]={t:Date.now(),l:d};return d}
const cpRows=(a,b,res)=>{const r=cpClip(a,b);if(!r)return[];const ix={};res.closures.forEach(c=>ix[c.no]=c);const out=[];(res.extras||[]).forEach(x=>{const t=L.dn(x.due),c=ix[x.no];if(t>=r[0]&&t<=r[1])out.push({x:x.kind,t,s:!c?"pending":c.action==="Deferred"?"deferred":c.on<=x.due?"ontime":"late"})});for(let t=r[0];t<=r[1];t++)L.orders(M,t).forEach(o=>{const c=ix[o.no];out.push({o,t,s:!c?"pending":c.action==="Deferred"?"deferred":c.on<=L.iso(t)?"ontime":"late"})});return out};
const cpKey=()=>cmp.tab==="weekly"?"w"+cmp.date:cmp.tab==="monthly"?"m"+cmp.month:"y"+cmp.year;
const weekOf=d=>{const t=L.dn(d),m=t-(L.wd(t)-1);return[m,m+6]};
const monthOf=m=>{const y=+m.slice(0,4),mo=+m.slice(5);return[Date.UTC(y,mo-1,1)/864e5,Date.UTC(y,mo,1)/864e5-1]};
async function cpLoad(){const key=cpKey(),run=++cpRun;CD={key,rows:null,parts:{},err:"",done:false};
 try{if(cmp.tab==="weekly"){const[a,b]=weekOf(cmp.date);CD.rows=cpRows(a,b,await cpClosures(a,b))}
  else if(cmp.tab==="monthly"){const[a,b]=monthOf(cmp.month);CD.rows=cpRows(a,b,await cpClosures(a,b))}
  else{for(let m=1;m<=12;m++){const a=Date.UTC(cmp.year,m-1,1)/864e5,b=Date.UTC(cmp.year,m,1)/864e5-1;const rs=cpRows(a,b,await cpClosures(a,b));if(run!==cpRun)return;CD.parts[m]=rs;if(m<12)adminShow&&adminShow()}CD.rows=[].concat(...[...Array(12)].map((_,i)=>CD.parts[i+1]||[]))}}
 catch(x){if(run===cpRun)CD.err=x.message}
 if(run===cpRun){CD.done=true;adminShow&&adminShow()}}
function cpStart(){if(CD.key!==cpKey())cpLoad()}
const cpSum=rs=>{rs=rs.filter(r=>!r.x);const n=k=>rs.filter(r=>r.s===k).length,t=rs.length,on=n("ontime"),la=n("late"),de=n("deferred"),pe=n("pending");return{t,on,la,de,pe,pct:t?Math.round(on/t*1000)/10:null,done:t?Math.round((on+la)/t*1000)/10:null}};
const cpPc=p=>p==null?"—":`<b style="color:${p>=95?COL.green:p>=80?COL.amber:COL.red}">${p}%</b>`;
const cpRow=(l,rs)=>{const s=cpSum(rs);return`<tr><td>${l}</td><td>${s.t}</td><td>${s.on}</td><td>${s.la}</td><td>${s.de}</td><td>${s.pe}</td><td>${cpPc(s.pct)}</td><td>${cpPc(s.done)}</td></tr>`};
const CPH=["Orders due","Closed on time","Closed late","Deferred","Pending","Compliance (on time)","Completion (closed)"];
const cpTbl=(first,rows)=>tbl([first,...CPH],rows);
const cpGroup=(rs,f)=>[...new Set(rs.map(f).map(x=>x||"Not set"))].sort().map(k=>cpRow(esc(k),rs.filter(r=>(f(r)||"Not set")===k)));
function cpBody(){
 const all=CD.rows||[],rs=all.filter(r=>!r.x),xs=all.filter(r=>r.x),s=cpSum(rs),kp=(v,l,c)=>`<div class="kpi" style="--c:${c}"><b>${v}</b><span>${l}</span></div>`;
 let title,buckets,chart="";
 if(cmp.tab==="weekly"){const[a,b]=weekOf(cmp.date);title=`Weekly compliance, ${dmy(L.iso(a))} to ${dmy(L.iso(b))}`;buckets=[...Array(7)].map((_,i)=>cpRow(`${DS[i]} ${dmy(L.iso(a+i)).slice(0,5)}`,rs.filter(r=>r.t===a+i)))}
 else if(cmp.tab==="monthly"){const[a,b]=monthOf(cmp.month);title=`Monthly compliance, ${MON[+cmp.month.slice(5)-1]} ${cmp.month.slice(0,4)}`;buckets=[];let t=a,n=1;while(t<=b){const e=Math.min(b,t+(7-L.wd(t)));buckets.push(cpRow(`Week ${n} (${L.iso(t).slice(8)}-${L.iso(e).slice(8)})`,rs.filter(r=>r.t>=t&&r.t<=e)));t=e+1;n++}}
 else{title=`Yearly compliance, January to December ${cmp.year}`;const pm=[...Array(12)].map((_,i)=>CD.parts[i+1]);buckets=pm.map((p,i)=>p?cpRow(MON[i],p):`<tr><td>${MON[i]}</td><td colspan="7" class="empty">${CD.err?"":"Loading..."}</td></tr>`);
  chart=card("Compliance by month (on time)",`<div class="cols">${pm.map((p,i)=>{const v=p?cpSum(p).pct:null;return`<div><em>${v==null?"—":v+"%"}</em><i style="height:${Math.max(3,(v||0)*1.3)}px;background:${v==null?COL.slate:v>=95?COL.green:v>=80?COL.amber:COL.red}"></i><span>${MON[i]}</span></div>`}).join("")}</div>`,COL.blue)}
 return PH(title)+`<div class="kpis">${kp(s.t,"Orders due",COL.blue)}${kp(s.on,"Closed on time",COL.green)}${kp(s.la,"Closed late",COL.violet)}${kp(s.de,"Deferred",COL.amber)}${kp(s.pe,"Pending",COL.red)}${kp(s.pct==null?"—":s.pct+"%","Compliance",s.pct==null||s.pct>=95?COL.green:s.pct>=80?COL.amber:COL.red)}</div>`+chart+
 `<h3 style="margin-top:18px">${cmp.tab==="weekly"?"Day by day":cmp.tab==="monthly"?"Week by week":"Month by month"}</h3>`+cpTbl(cmp.tab==="weekly"?"Day":cmp.tab==="monthly"?"Week":"Month",buckets)+
 `<h3 style="margin-top:18px">By location</h3>`+cpTbl("Location",cpGroup(rs,r=>r.o.e.loc))+`<h3 style="margin-top:18px">By frequency</h3>`+cpTbl("Frequency",M.settings.freqs.filter(f=>rs.some(r=>r.o.freq===f)).map(f=>cpRow(f,rs.filter(r=>r.o.freq===f))))+
 (xs.length?`<h3 style="margin-top:18px">Other orders (not part of the compliance percentage)</h3>`+tbl(["Kind","Orders due","Closed","Deferred","Pending"],Object.keys(KL).filter(k=>xs.some(r=>r.x===k)).map(k=>{const l=xs.filter(r=>r.x===k),n=q=>l.filter(r=>r.s===q).length;return`<tr><td>${KL[k]}</td><td>${l.length}</td><td>${n("ontime")+n("late")}</td><td>${n("deferred")}</td><td>${n("pending")}</td></tr>`})):"")+
 `<p class="hint">Compliance = orders closed on or before their due date, divided by all orders due. Completion also counts orders closed late. Deferred and pending orders count as not complied. Only dates from ${dmy(CFROM())} up to yesterday are assessed, and orders are taken from the current schedule.</p>`}
A.compliance=()=>{const tabs=[["weekly","Weekly"],["monthly","Monthly"],["yearly","Yearly"]],yrs=[...Array(6)].map((_,i)=>+L.iso(TD).slice(0,4)-i).filter(y=>y>=2026||y===cmp.year);
 const pick=cmp.tab==="weekly"?`<label>Week containing <input type="date" id="cpd" value="${cmp.date}"></label>`:cmp.tab==="monthly"?`<label>Month <input type="month" id="cpm" value="${cmp.month}"></label>`:`<label>Year <select id="cpy">${[...new Set([...yrs,cmp.year])].sort((a,b)=>b-a).map(y=>`<option${y===cmp.year?" selected":""}>${y}</option>`).join("")}</select></label>`;
 return`<div class="subtabs">${tabs.map(([k,n])=>`<button class="ghost${cmp.tab===k?" on":""}" data-ct="${k}">${n}</button>`).join("")}</div>
 <div class="bar noprint"><button class="ghost" data-cpn="-1">&lt; Previous</button>${pick}<button class="ghost" data-cpn="1">Next &gt;</button><button class="ghost" data-cpreload>Reload</button><button class="ghost" data-print>Print</button></div>
 <div class="bar noprint"><label>Count compliance from <input type="date" id="cpf" value="${CFROM()}"${R==="admin"?"":" disabled"}></label>${R==="admin"?`<button data-cpsave>Save start date</button>`:""}<span class="hint">Orders before this date are not counted (set it to the day the portal went live).</span></div>`+
 (CD.key!==cpKey()||(!CD.done&&cmp.tab!=="yearly")?`<p class="empty">Loading compliance...</p>`:CD.err?`<p class="empty">Could not load: ${esc(CD.err)}</p>`:cpBody())};


/* RELIABILITY: MTTR and MTBF from Breakdown notifications and corrective orders */
let rel={tab:"monthly",month:L.iso(TD).slice(0,7),year:+L.iso(TD).slice(0,4),hpd:24,src:{ntf:true,att:false,add:false}},RC={},RD={key:"",parts:{},err:"",done:false},relRun=0;
const relKey=()=>rel.tab==="monthly"?"m"+rel.month:"y"+rel.year;
const relMonths=()=>rel.tab==="monthly"?[rel.month]:[...Array(12)].map((_,i)=>rel.year+"-"+String(i+1).padStart(2,"0"));
async function relFetch(a,b){const hi=Math.min(b,TD);if(a>hi)return{breakdowns:[],orders:[]};const from=L.iso(a),to=L.iso(hi),k=from+"|"+to,h=RC[k];if(h&&Date.now()-h.t<3e5)return h.d;const d=await call("reliability_range",{from,to});RC[k]={t:Date.now(),d};return d}
async function relLoad(){const key=relKey(),run=++relRun,ms=relMonths();RD={key,parts:{},err:"",done:false};
 try{for(const m of ms){const[a,b]=monthOf(m);const d=await relFetch(a,b);if(run!==relRun)return;RD.parts[m]=d;if(ms.length>1&&m!==ms[11]&&route==="reliability")V.reliability()}}
 catch(x){if(run===relRun)RD.err=x.message}
 if(run===relRun){RD.done=true;if(route==="reliability")V.reliability()}}
const RSRC={ntf:"Breakdown notification",att:"Attention action order",add:"Corrective (CM) order"};
function relEvents(parts){const ev=[];let excl=0;Object.entries(parts).forEach(([m,p])=>{
 if(rel.src.ntf)(p.breakdowns||[]).forEach(x=>ev.push({m,eq:x.eq,name:x.name,area:x.area||"Not set",mins:x.mins}));
 (p.orders||[]).forEach(o=>{if(!rel.src[o.kind==="attention"?"att":"add"]||(o.kind==="additional"&&o.otype!=="CM"))return;if(o.state==="closed"&&o.mins!=null)ev.push({m,eq:o.eq,name:o.name,area:o.area||"Not set",mins:o.mins});else excl++})});return{ev,excl}}
const relDays=m=>{const[a,b]=monthOf(m);return Math.max(0,Math.min(b,TD)-a+1)};
function relStats(ev,days){const by={};ev.forEach(e=>{const r=by[e.eq]||(by[e.eq]={eq:e.eq,name:e.name,area:e.area,n:0,mins:0});r.n++;r.mins+=e.mins});
 const T=days*rel.hpd*60,rows=Object.values(by).map(r=>({...r,mttr:r.mins/r.n,mtbf:Math.max(0,T-r.mins)/r.n,av:T?Math.max(0,T-r.mins)/T*100:null})).sort((a,b)=>b.n-a.n||b.mins-a.mins);
 const N=rows.reduce((a,r)=>a+r.n,0),D=rows.reduce((a,r)=>a+r.mins,0),A=rows.length;
 return{rows,N,D,A,T,mttr:N?D/N:null,mtbf:N?Math.max(0,A*T-D)/N:null,av:A&&T?Math.max(0,A*T-D)/(A*T)*100:null}}
const fh=(m,d=1)=>m==null?"—":(m/60).toFixed(d),fp=p=>p==null?"—":p.toFixed(1)+"%";
const relRow=(l,st)=>`<tr><td>${l}</td><td>${st.N}</td><td>${fh(st.D,2)}</td><td>${fh(st.mttr,2)}</td><td>${fh(st.mtbf)}</td><td>${fp(st.av)}</td></tr>`;
function relBody(){const ms=Object.keys(RD.parts).sort(),{ev,excl}=relEvents(RD.parts),days=ms.reduce((a,m)=>a+relDays(m),0),st=relStats(ev,days),kp=(v,l,c)=>`<div class="kpi" style="--c:${c}"><b>${v}</b><span>${l}</span></div>`;
 const title=rel.tab==="monthly"?`MTTR and MTBF, ${MON[+rel.month.slice(5)-1]} ${rel.month.slice(0,4)}`:`MTTR and MTBF, January to December ${rel.year}`;
 const H=["Failures","Downtime (h)","MTTR (h)","MTBF (h)","Availability"];
 let h=PH(title)+`<div class="kpis">${kp(st.N,"Failures",COL.red)}${kp(st.A,"Equipment affected",COL.amber)}${kp(fh(st.D,2),"Downtime (h)",COL.violet)}${kp(fh(st.mttr,2),"MTTR (h)",COL.blue)}${kp(fh(st.mtbf),"MTBF (h)",COL.green)}${kp(fp(st.av),"Availability",COL.green)}</div>`;
 if(rel.tab==="yearly")h+=`<h3 style="margin-top:18px">Month by month</h3>`+tbl(["Month",...H],[...Array(12)].map((_,i)=>{const m=rel.year+"-"+String(i+1).padStart(2,"0"),d=relDays(m);return RD.parts[m]?relRow(MON[i],relStats(ev.filter(e=>e.m===m),d)):`<tr><td>${MON[i]}</td><td colspan="5" class="empty">${RD.err?"":d?"Loading...":"—"}</td></tr>`}));
 const ar=[...new Set(ev.map(e=>e.area))].sort();
 h+=`<h3 style="margin-top:18px">By area</h3>`+tbl(["Area",...H],ar.map(a=>relRow(esc(a),relStats(ev.filter(e=>e.area===a),days))))+
 `<h3 style="margin-top:18px">By equipment</h3>`+tbl(["Equipment","Area",...H],st.rows.map(r=>`<tr><td>${esc(r.name)}<small>${esc(r.eq)}</small></td><td>${esc(r.area)}</td><td>${r.n}</td><td>${fh(r.mins,2)}</td><td>${fh(r.mttr,2)}</td><td>${fh(r.mtbf)}</td><td>${fp(r.av)}</td></tr>`))+
 `<p class="hint">MTTR = total repair time / number of failures. MTBF = (operating time - repair time) / number of failures, where operating time is ${rel.hpd} hour(s) a day for every day of the period up to today, counted for each equipment that failed. Availability = (operating time - repair time) / operating time. Equipment with no failure in the period are not listed. Sources used: ${Object.keys(rel.src).filter(k=>rel.src[k]).map(k=>RSRC[k]).join(", ")||"none selected"}. Repair time of a notification is its breakdown time; repair time of an order is its closing End time minus Start time.${excl?` ${excl} selected order(s) were left out because they are not closed or have no start and end time.`:""}${rel.src.ntf&&(rel.src.att||rel.src.add)?" A breakdown that has both a notification and an order is counted twice.":""}</p>`;
 return h}
V.reliability=()=>{const v=$("#view");if(RD.key!==relKey())relLoad();
 const pick=rel.tab==="monthly"?`<label>Month <input type="month" id="rmo" value="${rel.month}"></label>`:`<label>Year <select id="ryr">${[...new Set([...Array(6)].map((_,i)=>+L.iso(TD).slice(0,4)-i).filter(y=>y>=2026).concat(rel.year))].sort((a,b)=>b-a).map(y=>`<option${y===rel.year?" selected":""}>${y}</option>`).join("")}</select></label>`;
 const ck=(k)=>`<label class="chk"><input type="checkbox" data-rs="${k}"${rel.src[k]?" checked":""}> ${RSRC[k]}s</label>`;
 v.innerHTML=`<div class="subtabs noprint">${[["monthly","Monthly"],["yearly","Yearly"]].map(([k,n])=>`<button class="ghost${rel.tab===k?" on":""}" data-rt="${k}">${n}</button>`).join("")}</div>
 <div class="bar noprint"><button class="ghost" data-rn="-1">&lt; Previous</button>${pick}<button class="ghost" data-rn="1">Next &gt;</button><label>Operating hours per day <input type="number" id="rhpd" min="1" max="24" step="1" value="${rel.hpd}" style="width:80px"></label><button class="ghost" data-rreload>Reload</button><button class="ghost" data-print>Print</button></div>
 <div class="bar noprint"><span class="hint">Failures from:</span>${ck("ntf")}${ck("att")}${ck("add")}</div>`+
 (RD.err?`<p class="empty">Could not load: ${esc(RD.err)}</p>`:rel.tab==="monthly"&&!RD.done?`<p class="empty">Loading...</p>`:relBody());
 v.onclick=e=>{const d=e.target.dataset;if(d.rt){rel.tab=d.rt;V.reliability()}else if(d.rn){const n=+d.rn;if(rel.tab==="monthly"){const y=+rel.month.slice(0,4),m=+rel.month.slice(5)-1+n;rel.month=new Date(Date.UTC(y,m,1)).toISOString().slice(0,7)}else rel.year+=n;V.reliability()}else if(d.rreload!==undefined){RC={};RD.key="";V.reliability()}else if(d.print!==undefined)window.print()};
 v.onchange=e=>{const t=e.target;if(t.id==="rmo"&&t.value)rel.month=t.value;else if(t.id==="ryr")rel.year=+t.value;else if(t.id==="rhpd")rel.hpd=Math.min(24,Math.max(1,Math.round(+t.value)||24));else if(t.dataset.rs)rel.src[t.dataset.rs]=t.checked;else return;V.reliability()}};

V.admin=()=>{if(R!=="admin"&&R!=="mgmt"){$("#view").textContent="Admin access only.";return}
 if(R!=="admin"&&sub==="sched")sub="closure";
 const show=adminShow=()=>{const v0=$("#view");v0.innerHTML=`<div class="subtabs">${[["closure","Closure history"],["orders","Maintenance order history"],["equip","Equipment details"],["sched","Maintenance scheduling"],["checklist","Checklist items"],["compliance","Compliance"]].filter(([k])=>R==="admin"||k!=="sched").map(([k,n])=>`<button class="ghost${sub===k?" on":""}" data-s="${k}">${n}</button>`).join("")}</div>${R!=="admin"?`<p class="hint noprint">View only.</p>`:""}${A[sub]()}`;
  if(R!=="admin"){v0.querySelectorAll("[data-k],[data-lk],[data-area],[data-t],[data-proc]").forEach(x=>x.disabled=true);v0.querySelectorAll("[data-add],[data-save],[data-addchk],[data-delchk],[data-cpsave]").forEach(x=>{const bar=x.parentElement;x.remove();bar&&bar.querySelectorAll(".hint").forEach(h=>h.remove())});if(sub==="equip"||sub==="checklist")v0.querySelectorAll(":scope > p.hint:not(.noprint)").forEach(h=>h.remove())}
  if(sub==="compliance")cpStart()};show();
 $("#view").oninput=e=>{const d=e.target.dataset;if(d.proc!==undefined){if(R==="admin"){M.procedures=M.procedures||{};M.procedures[d.proc]=e.target.value}return}if(d.lk!==undefined){M.library[d.li][d.lk]=d.lk==="seq"?+e.target.value:e.target.value;return}if(d.k&&d.i!==undefined)M.equipment[d.i][d.k]=e.target.value};
 $("#view").onchange=e=>{
    const d=e.target.dataset;
    if(e.target.id==="cpd"||e.target.id==="cpm"||e.target.id==="cpy"){if(e.target.value){if(e.target.id==="cpd")cmp.date=e.target.value;else if(e.target.id==="cpm")cmp.month=e.target.value;else cmp.year=+e.target.value;show()}return}
    if(e.target.id==="cpf"){if(R==="admin"&&e.target.value)M.settings.complianceFrom=e.target.value;return}
    if(e.target.id==="bfrom"){if(e.target.value){balFrom=e.target.value;BAL=null;show()}return}
    if(R!=="admin"&&(d.k!==undefined||d.lk!==undefined||d.area!==undefined||d.t!==undefined||d.proc!==undefined))return;

    // Equipment list filters
    if(e.target.id==="eqAreaFilter" || e.target.id==="eqTypeFilter"){
        if(e.target.id==="eqAreaFilter") eqAreaFilter=e.target.value;
        else eqTypeFilter=e.target.value;
        show();
        return;
    }

    // Checklist filters
    if(e.target.id==="ct" || e.target.id==="cf"){
        if(e.target.id==="ct") ct=e.target.value;
        else cf=e.target.value;
        show();
        return;
    }

    // Checklist item editing
    if(d.lk!==undefined){
        M.library[d.li][d.lk]=d.lk==="seq"?+e.target.value:e.target.value;
        return;
    }

    // Maintenance scheduling
    if(d.area!==undefined){
        M.areas[d.area]=+e.target.value;
        return;
    }

    if(d.t){
        (M.ticks[d.t]=M.ticks[d.t]||Array(7).fill(0))[d.f]=e.target.checked?1:0;
        return;
    }

    // Equipment record editing
    if(d.k && d.i!==undefined){
        M.equipment[d.i][d.k]=e.target.value;

        // Refresh filtered rows if the Area or Type of an equipment changes
        if(sub==="equip" && (d.k==="type" || d.k==="loc")){
            show();
        }
    }

    if(e.target.id==="hd") hd=e.target.value;
};
 $("#view").onclick=async e=>{const d=e.target.dataset;
  if(R!=="admin"&&(d.add!==undefined||d.save!==undefined||d.addchk!==undefined||d.delchk!==undefined||d.cpsave!==undefined||d.bprev!==undefined||d.bapply!==undefined))return;
  if(d.print!==undefined)window.print();
  else if(d.bprev!==undefined){if(!(L.dn(balFrom)>TD)&&balFrom!==M.settings.balanceFrom)return toast("The effective date must be after today.",1);e.target.disabled=true;setTimeout(()=>{balPreview();show()},30)}
  else if(d.bapply!==undefined){if(!BAL)return;if(M.settings.balanceFrom&&M.settings.balanceFrom!==BAL.from&&!confirm("A levelled schedule already starts on "+dmy(M.settings.balanceFrom)+". Changing the date changes how the days in between are shown in reports. Continue?"))return;e.target.disabled=true;try{M.equipment.forEach(e2=>{if(BAL.lv.day[e2.id]!==undefined)e2.day=BAL.lv.day[e2.id]});M.settings.balanceFrom=BAL.from;await call("master",{master:M});toast("Levelled schedule saved. It applies from "+dmy(BAL.from)+".");BAL=null}catch(x){toast(x.message,1)}show()}
  else if(d.ct){cmp.tab=d.ct;show()}
  else if(d.cpn){const n=+d.cpn;if(cmp.tab==="weekly")cmp.date=L.iso(L.dn(cmp.date)+7*n);else if(cmp.tab==="monthly"){const y=+cmp.month.slice(0,4),m=+cmp.month.slice(5)-1+n,t=new Date(Date.UTC(y,m,1));cmp.month=t.toISOString().slice(0,7)}else cmp.year+=n;show()}
  else if(d.cpreload!==undefined){CPC={};CD.key="";show()}
  else if(d.cpsave!==undefined){e.target.disabled=true;try{await call("master",{master:M});toast("Compliance start date saved.");CD.key="";show()}catch(x){toast(x.message,1)}e.target.disabled=false}
  else if(d.s){sub=d.s;show()}
  else if(d.load!==undefined){try{hist=await call("history",{date:hd});show()}catch(x){toast(x.message,1)}}
  else if(d.add!==undefined){
            // Clear filters so the newly added equipment is visible
            eqAreaFilter="";
            eqTypeFilter="";

            const l=M.equipment[M.equipment.length-1]?.id||"EQ-0000";
            const m=/^(.*?)(\d+)$/.exec(l);

            M.equipment.push({
                id:m[1]+String(+m[2]+1).padStart(m[2].length,"0"),
                name:"",
                type:"",
                loc:"",
                make:"",
                rating:"",
                install:"",
                status:"Active",
                remarks:"",
                crit:"",
                start:""
            });
            show();
        }
  else if(d.addchk!==undefined){if(!ct||!cf)return toast("Select an equipment type and a frequency first.",1);
   const pre=ct.slice(0,4).toUpperCase().replace(/[^A-Z]/g,"")+"-"+cf.slice(0,3).toUpperCase()+"-",nums=M.library.filter(r=>r.id.startsWith(pre)).map(r=>+r.id.slice(pre.length)||0),seqs=M.library.filter(r=>r.type===ct&&r.freq===cf).map(r=>+r.seq||0);
   M.library.push({id:pre+String(Math.max(0,...nums)+1).padStart(2,"0"),type:ct,freq:cf,seq:Math.max(0,...seqs)+1,item:"",readReq:"No",unit:"",criteria:"",mand:"Yes",active:"Yes",ref:""});show()}
  else if(d.delchk!==undefined){if(confirm("Delete this checklist item? Records already saved are not affected.")){M.library.splice(+d.delchk,1);show()}}
  else if(d.save!==undefined){if(sub==="checklist"&&M.library.some(r=>!String(r.item).trim()))return toast("Fill in or delete the empty checklist items first.",1);e.target.disabled=true;try{await call("master",{master:M});toast("Saved to the data repository.")}catch(x){toast(x.message,1)}e.target.disabled=false}}};

(async()=>{try{await load()}catch(e){$("#view").innerHTML=`<p class="empty">Could not load data: ${esc(e.message)}</p>`}})();
})();
